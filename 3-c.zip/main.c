/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int a[100],sum=0;
   int i=0,avg;
   printf("enter the data value of elephant");
   scanf("%d\n",&a[i]);
   for(i=0;i<100;i++)
   {    sum=sum+a[i];
        avg=sum/100;
        
   }
   printf("the abg of the elephant=%d",avg);
   
}
